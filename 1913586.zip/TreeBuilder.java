/**
 * This class represents the binary tree
 * @author Enikeeva Alina
 */

public class TreeBuilder<T> {

   
   public LinkedBinaryTree<T> buildTree(T array[]) {	
	   // initialize the queue
       LinkedQueue<T> dataQueue = new LinkedQueue<T>();
       
       // put elements of T array into dataQueue
       for (int i=0; i<array.length; i++) {
           dataQueue.enqueue(array[i]);
       }
     
       LinkedQueue<BinaryTreeNode<T>> parentQueue = new LinkedQueue<BinaryTreeNode<T>>();
       BinaryTreeNode<T> root = new BinaryTreeNode<T>(dataQueue.dequeue());
       // enqueue the root node on parentQueue
       parentQueue.enqueue(root); 
       
      
       
       while(dataQueue.isEmpty()==false) {
    	   
    	   // declare left, right nodes and the paret node
           T a = dataQueue.dequeue(); 
           T b = dataQueue.dequeue(); 
           BinaryTreeNode<T> parent = parentQueue.dequeue();
          
           //check if the child node is null, if not than add node storing a as child of parent and enqueue on parentQueue
           if(a != null)  {
               BinaryTreeNode<T> node = new BinaryTreeNode<T>(a);
               parent.setLeft(node); 
               parentQueue.enqueue(node); 
           }
           if(b != null) {
               BinaryTreeNode<T> node = new BinaryTreeNode<T>(b);
               parent.setRight(node); 
               parentQueue.enqueue(node); 
           }
       }
      
       //return the LinkedBinaryTree object with the root node from above
       return new LinkedBinaryTree<T>(root);
   }

}
